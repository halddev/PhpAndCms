<?php 

class Config {

    const SMTP_HOST = 'smtp.mailtrap.io';

    const SMTP_PORT = 2525;

    const SMTP_USER = 'cee766fe1a8b20';

    const SMTP_PASSWORD = '181919bbc658d6';
    
}

?>