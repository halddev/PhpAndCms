<?php 

class Example{
    public function display(){
        echo "method from class";
    }
}

?>